# SendMessageRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**phoneNumber** | **string** | The number you wish to send the message to | [optional] 
**message** | **string** | The message you wish to send | [optional] 
**deviceId** | **int** | The device you wish to send the message using | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


